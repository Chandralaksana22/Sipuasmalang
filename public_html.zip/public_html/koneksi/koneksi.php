<?php
$host = 'localhost';
$username = 'id17361110_sipuas';
$password = 'Dikbudmalang#12';
$db_name = 'id17361110_dbsipuas'; // nama databasenya
$koneksi = new mysqli($host, $username, $password, $db_name);
date_default_timezone_set('Asia/Jakarta');
?>