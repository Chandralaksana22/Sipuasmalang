<?php 
	include "../koneksi/koneksi.php";
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../admin/login.php?pesan=belum_login");
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>SIPUAS-Sistem Informasi Survei Kepuasan Pelayanan</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../assets/img/icon.ico" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="../assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/atlantis.min.css">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="../assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<div class="main-header">
			<!-- Logo Header -->
			<div class="logo-header" data-background-color="blue">
				
				<a href="index.php" class="logo">
					<img src="../assets/img/logo.png" alt="navbar brand" class="navbar-brand">
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">
						<i class="icon-menu"></i>
					</span>
				</button>
				<button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
				<div class="nav-toggle">
					<button class="btn btn-toggle toggle-sidebar">
						<i class="icon-menu"></i>
					</button>
				</div>
			</div>
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg" data-background-color="blue2">
			</nav>
			<!-- End Navbar -->
		</div>

		<!-- Sidebar -->
		<div class="sidebar sidebar-style-2">			
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content">
					<div class="user">
						<div class="avatar-sm float-left mr-2">
							<img src="../assets/img/profile.jpg" alt="..." class="avatar-img rounded-circle">
						</div>
						<div class="info">
							<a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
								<span>
									<span><?=$_SESSION['nama'];?></span>
									<span class="user-level"><?php echo $_SESSION['email']; ?></span>
								</span>
							</a>
							<div class="clearfix"></div>

							<div class="collapse in" id="collapseExample">
								<ul class="nav">
									<li>
										<a href="profile.php">
											<span class="link-collapse">Edit Profil</span>
										</a>
									</li>
									<li>
										<a href="logout.php">
											<span class="link-collapse">Logout</span>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<ul class="nav nav-primary">
						<li class="nav-item active">
							<a  href="index.php"  aria-expanded="false">
								<i class="fas fa-home"></i>
								<p>Dashboard</p>
							</a>
						</li>
						<li class="nav-section">
							<span class="sidebar-mini-icon">
								<i class="fa fa-ellipsis-h"></i>
							</span>
							<h4 class="text-section">Laporan</h4>
						</li>
						<li class="nav-item">
							<a href="surveikepuasan.php">
								<i class="fab fa-stack-overflow"></i>
								<p>Survei Kepuasan</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="kotaksaran.php">
								<i class="fab fa-pushed"></i>
								<p>Kotak Saran</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="surveimasyarakat.php">
								<i class="fab fa-cloudversify"></i>
								<p>Survei Masyarakat</p>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Sidebar -->
		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Sipuas</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="index.php">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="surveimasyarakat.php">Survei Masyarakat</a>
							</li>
						</ul>
						<div class="ml-5 card-tools">
							<a href="excelsurveimasyarakat.php" class="btn btn-info btn-border btn-round btn-sm mr-2">
							<span class="btn-label">
							<i class="fa fa-pencil"></i>
							</span>Export</a>
							<a href="cetaksurveimasyarakat.php" class="btn btn-info btn-border btn-round btn-sm">
							<span class="btn-label">
							<i class="fa fa-print"></i>
							</span>Print</a>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
									<div class="card-title">Statistik</div>
									<div class="card-category">Informasi tentang profile masyarakat</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-6 col-md-6">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Jenis Kelamin</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT jk, COUNT(id_survei) FROM survei GROUP BY jk");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['jk'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-6 col-md-6">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Usia</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT usia, COUNT(id_survei) FROM survei GROUP BY usia");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['usia'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-6 col-md-6">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Jenjang Pendidikan</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT Pendidikan, COUNT(id_survei) FROM survei GROUP BY Pendidikan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['Pendidikan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-6 col-md-6">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Pekerjaan</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT pekerjaan, COUNT(id_survei) FROM survei GROUP BY pekerjaan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['pekerjaan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
									<div class="card-title">Statistik</div>
									<div class="card-category">Informasi tentang persyaratan pelayanan</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan keberadaan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT keberadaaninformasi, COUNT(id_survei) FROM survei GROUP BY keberadaaninformasi");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['keberadaaninformasi'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan kemudahan mendapatkan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kemudahanmendapatkaninformasi, COUNT(id_survei) FROM survei GROUP BY keberadaaninformasi");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kemudahanmendapatkaninformasi'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th> Apakah anda puas dengan kejelasan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kejelasaninformasi, COUNT(id_survei) FROM survei GROUP BY kejelasaninformasi");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kejelasaninformasi'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th> Apakah anda puas dengan kemudahan memenuhi persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kemudahanpelayanan, COUNT(id_survei) FROM survei GROUP BY kemudahanpelayanan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kemudahanpelayanan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
									<div class="card-title">Statistik</div>
									<div class="card-category">Informasi tentang sistem, mekanisme dan prosedur</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan keberadaan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT informasiprosedur, COUNT(id_survei) FROM survei GROUP BY informasiprosedur");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['informasiprosedur'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan kemudahan mendapatkan informasi mengenai sistem, mekanisme dan prosedur pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kemudahaninformasiprosedur, COUNT(id_survei) FROM survei GROUP BY kemudahaninformasiprosedur");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kemudahaninformasiprosedur'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan kejelasan informasi mengenai sistem, mekanisme dan prosedur pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kejelasaninformasiprosedur, COUNT(id_survei) FROM survei GROUP BY kejelasaninformasiprosedur");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kejelasaninformasiprosedur'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan kemudahan menjalankan sistem, mekanisme dan prosedur pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kemudahanpelayanan, COUNT(id_survei) FROM survei GROUP BY kemudahanpelayanan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kemudahanpelayanan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
									<div class="card-title">Statistik</div>
									<div class="card-category">Informasi tentang penanganan pengaduan, paran dan masukan</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan keberadaan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT informasipelayanan, COUNT(id_survei) FROM survei GROUP BY informasipelayanan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['informasipelayanan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan ketersediaan pengaduan masyarakat? (Berupa media pengaduan seperti kotak pengaduan, buku panduan, sms pengaduan, call center pengaduan, dan yang lainnya)</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT ketersediaanpengaduan, COUNT(id_survei) FROM survei GROUP BY ketersediaanpengaduan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['ketersediaanpengaduan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan ketepatan hasil layanan yang sesuai dengan ketentuan yang berlaku?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT ketepatanlayanan, COUNT(id_survei) FROM survei GROUP BY ketepatanlayanan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['ketepatanlayanan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<div class="row">
			            <div class="col-9">
			            <div class=" text header-footer">SIPUAS</div>
			            <p class="subjudul sub-header-footer sub-header-footer-mobile text-shadow">Sistem Informasi Survei Kepuasan Pelayanan Dinas Pendidikan dan Kebudayaan Kota Malang<br><a href="#" data-toggle="modal" class="modalfont dev-mobile" data-target="#modalDiscount"> Develop by Tim Magang UM Antara 2021</a></p>
			            </div>
			            <div class="col-1">
			            </div>
			            <div class="col-2 mr-set">
			                <img class="image-footer img-fluid mx-auto d-block" src="../img/logo-footer.png">
			            </div>
			        </div>				
				</div>
			</footer>
		</div>
		
		<!-- Custom template | don't include it in your project! -->
	<div class="custom-template">
			<div class="title">Settings</div>
			<div class="custom-content">
				<div class="switcher">
					<div class="switch-block">
						<h4>Navbar Header</h4>
						<div class="btnSwitch">
							<button type="button" class="changeTopBarColor" data-color="dark"></button>
							<button type="button" class="changeTopBarColor" data-color="blue"></button>
							<button type="button" class="changeTopBarColor" data-color="purple"></button>
							<button type="button" class="changeTopBarColor" data-color="light-blue"></button>
							<button type="button" class="changeTopBarColor" data-color="green"></button>
							<button type="button" class="changeTopBarColor" data-color="orange"></button>
							<button type="button" class="changeTopBarColor" data-color="red"></button>
							<button type="button" class="changeTopBarColor" data-color="white"></button>
							<br/>
							<button type="button" class="changeTopBarColor" data-color="dark2"></button>
							<button type="button" class="selected changeTopBarColor" data-color="blue2"></button>
							<button type="button" class="changeTopBarColor" data-color="purple2"></button>
							<button type="button" class="changeTopBarColor" data-color="light-blue2"></button>
							<button type="button" class="changeTopBarColor" data-color="green2"></button>
							<button type="button" class="changeTopBarColor" data-color="orange2"></button>
							<button type="button" class="changeTopBarColor" data-color="red2"></button>
						</div>
					</div>
					<div class="switch-block">
						<h4>Sidebar</h4>
						<div class="btnSwitch">
							<button type="button" class="selected changeSideBarColor" data-color="white"></button>
							<button type="button" class="changeSideBarColor" data-color="dark"></button>
							<button type="button" class="changeSideBarColor" data-color="dark2"></button>
						</div>
					</div>
					<div class="switch-block">
						<h4>Background</h4>
						<div class="btnSwitch">
							<button type="button" class="changeBackgroundColor" data-color="bg2"></button>
							<button type="button" class="changeBackgroundColor selected" data-color="bg1"></button>
							<button type="button" class="changeBackgroundColor" data-color="bg3"></button>
							<button type="button" class="changeBackgroundColor" data-color="dark"></button>
						</div>
					</div>
				</div>
			</div>
			<div class="custom-toggle">
				<i class="flaticon-settings"></i>
			</div>
		</div>
		<!-- End Custom template -->
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>
	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	
	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
	
	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="../assets/js/setting-demo2.js"></script>
	<script >
		$(document).ready(function() {
			$('#basic-datatables').DataTable({
			});

			$('#multi-filter-select').DataTable( {
				"pageLength": 5,
				initComplete: function () {
					this.api().columns().every( function () {
						var column = this;
						var select = $('<select class="form-control"><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
								);

							column
							.search( val ? '^'+val+'$' : '', true, false )
							.draw();
						} );

						column.data().unique().sort().each( function ( d, j ) {
							select.append( '<option value="'+d+'">'+d+'</option>' )
						} );
					} );
				}
			});

			// Add Row
			$('#add-row').DataTable({
				"pageLength": 5,
			});

			var action = '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

			$('#addRowButton').click(function() {
				$('#add-row').dataTable().fnAddData([
					$("#addName").val(),
					$("#addPosition").val(),
					$("#addOffice").val(),
					action
					]);
				$('#addRowModal').modal('hide');

			});
		});
	</script>
</body>
</html>