<?php 
	include "../koneksi/koneksi.php";
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../admin/login.php?pesan=belum_login");
	}
?>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>SIPUAS-Sistem Informasi Survei Kepuasan Pelayanan</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../assets/img/icon.ico" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="../assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/atlantis.min.css">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="../assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<!-- End Sidebar -->
		<div>
			<div>
				<?php
					header("Content-type: application/vnd-ms-excel");
					header("Content-Disposition: attachment; filename=Laporan Saran.xls");
					?>
					<div class="row">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
									<div class="card-title">Statistik</div>
									<div class="card-category">Informasi tentang profile masyarakat</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-6 col-md-6">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Jenis Kelamin</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT jk, COUNT(id_survei) FROM survei GROUP BY jk");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['jk'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-6 col-md-6">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Usia</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT usia, COUNT(id_survei) FROM survei GROUP BY usia");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['usia'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-6 col-md-6">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Jenjang Pendidikan</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT Pendidikan, COUNT(id_survei) FROM survei GROUP BY Pendidikan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['Pendidikan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-6 col-md-6">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Pekerjaan</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT pekerjaan, COUNT(id_survei) FROM survei GROUP BY pekerjaan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['pekerjaan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
									<div class="card-title">Statistik</div>
									<div class="card-category">Informasi tentang persyaratan pelayanan</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan keberadaan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT keberadaaninformasi, COUNT(id_survei) FROM survei GROUP BY keberadaaninformasi");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['keberadaaninformasi'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan kemudahan mendapatkan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kemudahanmendapatkaninformasi, COUNT(id_survei) FROM survei GROUP BY keberadaaninformasi");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kemudahanmendapatkaninformasi'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th> Apakah anda puas dengan kejelasan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kejelasaninformasi, COUNT(id_survei) FROM survei GROUP BY kejelasaninformasi");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kejelasaninformasi'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th> Apakah anda puas dengan kemudahan memenuhi persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kemudahanpelayanan, COUNT(id_survei) FROM survei GROUP BY kemudahanpelayanan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kemudahanpelayanan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
									<div class="card-title">Statistik</div>
									<div class="card-category">Informasi tentang sistem, mekanisme dan prosedur</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan keberadaan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT informasiprosedur, COUNT(id_survei) FROM survei GROUP BY informasiprosedur");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['informasiprosedur'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan kemudahan mendapatkan informasi mengenai sistem, mekanisme dan prosedur pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kemudahaninformasiprosedur, COUNT(id_survei) FROM survei GROUP BY kemudahaninformasiprosedur");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kemudahaninformasiprosedur'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan kejelasan informasi mengenai sistem, mekanisme dan prosedur pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kejelasaninformasiprosedur, COUNT(id_survei) FROM survei GROUP BY kejelasaninformasiprosedur");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kejelasaninformasiprosedur'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan kemudahan menjalankan sistem, mekanisme dan prosedur pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT kemudahanpelayanan, COUNT(id_survei) FROM survei GROUP BY kemudahanpelayanan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['kemudahanpelayanan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
									<div class="card-title">Statistik</div>
									<div class="card-category">Informasi tentang penanganan pengaduan, paran dan masukan</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan keberadaan informasi mengenai persyaratan pelayanan?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT informasipelayanan, COUNT(id_survei) FROM survei GROUP BY informasipelayanan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['informasipelayanan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1">
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan ketersediaan pengaduan masyarakat? (Berupa media pengaduan seperti kotak pengaduan, buku panduan, sms pengaduan, call center pengaduan, dan yang lainnya)</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT ketersediaanpengaduan, COUNT(id_survei) FROM survei GROUP BY ketersediaanpengaduan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['ketersediaanpengaduan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1"ss >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Apakah anda puas dengan ketepatan hasil layanan yang sesuai dengan ketentuan yang berlaku?</th>
													<th>Jumlah</th>
												</tr>
											</thead>
											<tbody>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT ketepatanlayanan, COUNT(id_survei) FROM survei GROUP BY ketepatanlayanan");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['ketepatanlayanan'] ?></td>
													<td><?= $dt['COUNT(id_survei)'] ?></td>
												</tr>
												<?php
										    endwhile;
										    ?> 
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					</div>
				</div>
			</div>

		</div>
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>
	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	
	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
	
	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="../assets/js/setting-demo2.js"></script>
</body>