<?php 
	include "../koneksi/koneksi.php";
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../admin/login.php?pesan=belum_login");
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>SIPUAS-Sistem Informasi Survei Kepuasan Pelayanan</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../assets/img/icon.ico" type="image/x-icon"/>
</head>
<body>
	<div class="wrapper">
	
		<div>
			<div class="content">
				<div class="page-inner">
					<?php
					header("Content-type: application/vnd-ms-excel");
					header("Content-Disposition: attachment; filename=Laporan Saran.xls");
					?>
					<div class="page-header">
						<center><h4 class="page-title">Sipuas-Laporan Kotak Saran</h4></center>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table border="1" >
											<thead>
												<tr>
													<th>Nomor</th>
													<th>Waktu</th>
													<th>Saran</th>
												</tr>
												<?php
												// Tampilkan semua data
											    $q = $koneksi->query("SELECT * FROM kotak_saran");

											    $no = 1; // nomor urut
											    while ($dt = $q->fetch_assoc()) :
											    ?>
											</thead>
											<tbody>
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $dt['tanggal'] ?></td>
													<td><?= $dt['saran'] ?></td>
												</tr>
											</tbody>
											 <?php
										    endwhile;
										    ?> 
										</table>
										<script>
											window.print();
										</script>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>