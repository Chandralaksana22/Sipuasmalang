<?php 
	include "../koneksi/koneksi.php";
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../admin/login.php?pesan=belum_login");
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>SIPUAS-Sistem Informasi Survei Kepuasan Pelayanan</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../assets/img/icon.ico" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="../assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<script src="../assets/Chart.js/Chart.bundle.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/atlantis.min.css">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="../assets/css/demo.css">
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Laporan survei.xls");
	?>
</head>
  <?php
  	include "../koneksi/koneksi.php";
     // perintah tampil data
     $q = mysqli_query($koneksi, "SELECT * FROM kepuasan");
     
     $total = 0;
     $tot_bayar = 0;

     while ($r = $q->fetch_assoc()) {
      // total adalah hasil 
      $total = $r['puas'] + $r['tidak'];
     ?>
<body>
	<div class="wrapper">
		<!-- Sidebar -->
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<center><h4 class="page-title">Sipuas-Laporan Survei</h4></center>
					</div>
					<div class="row row-card-no-pd mt-2">
						<div class="col-4">
							<div class="card card-stats card-round">
								<div class="card-body ">
											<div class="icon-big text-center">
												<i class="flaticon-success text-success"></i>
											</div>
											<div class="numbers">
												<p class="card-category text-center">Puas : <?= $r['puas'] ?></p>
											</div>
								</div>
							</div>
						</div>
						<div class="col-4">
							<div class="card card-stats card-round">
								<div class="card-body">
											<div class="icon-big text-center">
												<i class="flaticon-error text-danger"></i>
											</div>
											<div class="numbers">
												<p class="card-category text-center">Tidak Puas :  <?= $r['tidak'] ?></p>
											</div>
								</div>
							</div>
						</div>
						<div class="col-4">
							<div class="card card-stats card-round">
								<div class="card-body ">
											<div class="icon-big text-center">
												<i class="flaticon-chart-pie text-primary"></i>
											</div>
											<div class="numbers">
												<p class="card-category text-center">Total Pengisian : <?= $total ?></p>
											</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1" >
											<thead>
												<tr>
													<th>Puas</th>
													<th>Tidak Puas</th>
													<th>Total</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td><?= $r['puas'] ?></td>
													<td><?= $r['tidak'] ?></td>
													<td><?= $total ?></td>
												</tr>
											</tbody> 
										</table>
										<script>
											window.print();
										</script>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>

	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="../assets/js/setting-demo.js"></script>
	<script src="../assets/js/demo.js"></script>
	<script>
    var randomScalingFactor = function() {
        return Math.round(Math.random() * 100);
    };
    var randomColorFactor = function() {
        return Math.round(Math.random() * 255);
    };
    var randomColor = function(opacity) {
        return 'rgba(' + randomColorFactor() + ',' + randomColorFactor() + ',' + randomColorFactor() + ',' + (opacity || '.3') + ')';
    };

    var config = {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [
                     <?= $r['puas'] ?>,
                    <?= $r['tidak'] ?>,
                ],
                backgroundColor: [
                    "#0F9D58",
                    "#DB4437",
                ],
                label: 'Dataset 1'
            }],
            labels: [
                "Puas",
                "Tidak Puas",
            ]
        },
        options: {
            responsive: true,
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Statistik Survei'
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    };

    window.onload = function() {
        var ctx = document.getElementById("chart-area").getContext("2d");
        window.myDoughnut = new Chart(ctx, config);
    };

  
    </script>
</body>
<?php   
				     }
				     ?>
</html>